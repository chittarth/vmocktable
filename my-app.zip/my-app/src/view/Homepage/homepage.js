import React ,{ Component}from 'react'
import {Grid, Button,Dropdown,Header} from 'semantic-ui-react'
import ReactDOM from 'react-dom';
import './homepage.css';
import SideBar from '../../component/SideBar/SideBar';
import MessageWindow from '../../component/MessageWindow/MessageWindow';

class Homepage extends Component {
   constructor(props){
        super(props);
        this.state = {
          myState: true
        }
    }
    render(){
      
        return (
            <div className="parent-div">
              <Grid>
                  <Grid.Row>
                      <Grid.Column width={12}>
                         <SideBar />
                      </Grid.Column>
                      
                  </Grid.Row>
              </Grid>
            </div>
        )
    }

    
  
}

export default Homepage;
