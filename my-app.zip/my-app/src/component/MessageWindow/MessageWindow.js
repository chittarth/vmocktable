import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Grid, Card, TextArea, Button, Dropdown, Form, Radio } from 'semantic-ui-react'
import './MessageWindow.scss';
import { List, Image } from 'semantic-ui-react'
// import '../../assets/userImage/'

class MessageWindow extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: true,
            booleans: {
                Sonalika: false,
                Maverick: false,
                Nevaeh: false,
                Nevaeh: false,
                Jaylen: false
            },
            display: false,
            newText: null
        }
        this.handleClick = this.handleClick.bind(this);
    }
    handleClick(name) {
        // console.log(event.target.innerText);
        const boolean = this.state.booleans;
        boolean[name] = true;
        this.setState(
            {
                booleans: boolean
            }
        );


    };

    handleMessage = (e) => {
        console.log(e.target.value)
        this.setState({
            newText: e.target.value
        })


    }
    fillData = () => {
        this.setState({
            boolean: true
        })
        if(this.state.boolean){
            let ele = document.getElementById('container');
            ele.innerHTML += this.state.newText;
        }
       
    }

    render() {
        console.log(this.props.profile)
        return (
            <div className="message-window">
                <Grid >
                    <Grid.Row>
                        <Grid.Column >
                            <h3 style={{ color: "grey" }}>MAILBOX</h3>
                        </Grid.Column>
                    </Grid.Row>

                    <Grid style={{ padding: "0px" }} celled>
                        <Grid.Row >

                            <Grid.Column width={6}>
                                <List divided relaxed >
                                    {this.props.profile.map((item) => {
                                        return (
                                            <List.Item onClick={() => this.handleClick(item.name)}>

                                                <Image className="user-image" src={require('../../assets/userimage/' + item.image).default} />

                                                <List.Content>
                                                    <List.Header as='a'> {item.name}</List.Header>
                                                    <List.Description className="message-body">
                                                        {item.message}
                                                    </List.Description>
                                                </List.Content>

                                            </List.Item>

                                        )
                                    })
                                    }
                                </List>
                            </Grid.Column>
                            <Grid.Column style={{ backgroundColor: "lightGrey" }} width={10}>
                                <Grid.Row >
                                    {this.props.profile.map((item) => {

                                        if (this.state.booleans[item.name]) {
                                            return (
                                                <div>
                                                    <Card.Group >
                                                        <Card >
                                                            <Card.Content>
                                                                <Image
                                                                    floated='left'

                                                                    className="user-image"
                                                                    src={require('../../assets/userimage/' + item.image).default}
                                                                />


                                                                <Card.Description>
                                                                    <strong>{item.message}</strong>
                                                                </Card.Description>
                                                            </Card.Content>
                                                        </Card>
                                                    </Card.Group>
                                                </div>
                                            );
                                        }

                                    })
                                    }
                                    {this.state.boolean && 
                                           
                                                <div id="container" style={{marginLeft:"150px"}}>
                                                    <Card.Group >
                                                        <Card >
                                                            <Card.Content >
                                                                <Card.Description>
                                                                    <strong>{this.state.newText}</strong>
                                                                </Card.Description>
                                                            </Card.Content>
                                                        </Card>
                                                    </Card.Group>
                                                </div>
                                    

                             
                                    }

                                </Grid.Row>
                                <Grid.Row className="text-Area">
                                    <Grid.Column>
                                        <Form >
                                            <TextArea onInput={(e) => { this.handleMessage(e) }} placeholder='Write a message' style={{ minHeight: 100 }} />
                                        </Form>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row >
                                    <Grid.Column>
                                        <Button onClick={() => this.fillData()} style={{ borderRadius: '0px', padding: "8px 40px 8px 40px" }} floated="right">Send</Button>
                                    </Grid.Column>
                                </Grid.Row>

                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Grid>

            </div>
        )
    }



}
export default MessageWindow;
