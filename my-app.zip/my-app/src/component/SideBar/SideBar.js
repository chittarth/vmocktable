import React ,{ Component}from 'react';
import ReactDOM from 'react-dom';
import {Grid,TextArea, Button,Dropdown,Form,Tab, Radio} from 'semantic-ui-react'
import MessageWindow from '../MessageWindow/MessageWindow';
import './SideBar.scss';
import profile from'../../Mock/profile.json'

const panes = [
    { menuItem: 'Home', render: () => <Tab.Pane><MessageWindow profile={profile}/></Tab.Pane> },
    { menuItem: 'Stats', render: () => <Tab.Pane>Stats</Tab.Pane> }
  ]
class SideBar extends Component {
    constructor(props){
         super(props);
         this.state = {
           value: true
         }
     }
     render(){
       
         return (
             <div  className="caption-button">
                 <Grid>
                     <Grid.Row >
                         <Grid.Column >
                         <Tab menu={{ fluid: true, vertical: true, tabular: true }} panes={panes} />
                         </Grid.Column>    
                     </Grid.Row>
                    
                 </Grid>
                
             </div>
         )
     }
 
     
   
 }
 
 export default SideBar;
 